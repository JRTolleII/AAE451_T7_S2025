% Consumed Fuel
%{
%}
function fc = ffc(W,R)
    fc = W*(1-R); return;
end